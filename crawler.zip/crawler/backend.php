<?php
//header('Content-Type: text/html; charset=utf-8');

require("BaseCr.class.php");
require("Crawler.class.php");

exec("chcp 65001");
fputs(STDOUT, "Введите доменное имя сайта: \r\n");
$temp = trim(fgets(STDIN));

//$temp = 'http://shop.by';
//$temp = 'http://bbs.people.com.cn';
//$temp = 'http://www.nytimes.com';

$temp = str_replace('www.', '', $temp);

$pos = strpos($temp, 'http://');
if($pos === false){
    $temp = 'http://' . $temp;
}

$slash = substr($temp, -1);
if($slash != '/'){
    $st = $temp . '/';
}
else{
    $st = $temp;
}

$str = $st . '';

$clObj = new Crawler($str, $st);
$clObj->getInfo();

$baseObj = BaseCr::getInstance();
$baseObj->cTable();

foreach($clObj->desc as $value){
    $baseObj->setInfo($value['Domain'], $value['Link'], $value['Content']);
    fputs(STDOUT, iconv_substr($value['Content'], 0, 50, 'utf-8') . "... " . $value['Link'] . "\r\n");
}
?>