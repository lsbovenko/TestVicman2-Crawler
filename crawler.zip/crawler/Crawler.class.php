<?php
class Crawler{
    public $str;
    public $st;
    public $allContent;
    public $headers = array();
    public $desc = array();
    public $links = array();

    function __construct($str, $st){
        $this->str = $str;
        $this->st = $st;
    }

    function getHeaders($headers){
        $head = array();
        foreach($headers as $hValue){
            $tempValue = explode(':', $hValue, 2);
            if(isset($tempValue[1])){
                $head[trim($tempValue[0])] = trim($tempValue[1]);
                if(preg_match('/\.*charset\s*=\s*([a-zA-Z0-9\-]*)\s*/', $hValue, $out)){
                    $head['Charset'] = strtolower($out[1]);
                }
            }
            else{
                $head[] = $hValue;
                if(preg_match('#HTTP/[0-9\.]+\s+([0-9]+)#', $hValue, $out)){
                    $head['Response_code'] = intval($out[1]);
                }
            }
        }
        return $head;
    }

    function getDesc($charset){
        preg_match('/<\s*meta\s+name\s*=\s*"\s*description\s*"\s+content\s*=\s*"([^"]*)/', $this->allContent, $descContent);
        if($descContent[1] != null){
            if($charset != ''){
                $content = iconv($charset, 'utf-8', $descContent[1]);
//                $content = mb_convert_encoding($descContent[1], 'utf-8', $charset);
            }
            else{
                $content = $descContent[1];
//                $content = mb_convert_encoding($descContent[1], 'utf-8');
            }
            $this->desc[] = array('Domain' => $this->st, 'Link' => $this->str, 'Content' => $content, 'Charset' => $charset);
//            $this->desc[] = array('Link' => $this->str, 'Content' => $descContent[1], 'Charset' => $charset);
        }
        else{
            fputs(STDERR, "No description content at $this->str \r\n");
//            echo "No description content at $this->str \r\n";
        }
    }

    function getLinks(){
        preg_match_all('/<\s*a.*?href\s*=\s*"(.*?)".*?>/', $this->allContent, $hrefContent);
        if($hrefContent[1] != null){
            foreach($hrefContent[1] as $hrefValue){
                preg_match('#.*/.+/+#', $hrefValue, $hreContent[]);
            }
            if($hreContent != null){
                foreach($hreContent as $hreValue){
                    if($hreValue[0] != null){
                        if($hreValue[0]{0} == "/"){
                            $hrContent[] = substr($this->st, 0, strlen($this->st)-1) . $hreValue[0];
                        }
                        else{
                            $hrContent[] = str_replace('www.', '', $hreValue[0]);
                        }
                    }
                }
                $hContent = array_unique($hrContent);
                foreach($hContent as $hValue){
                    $tLinks[] = $hValue;
                }
                $fLinks = array_merge($this->links, $tLinks);
                $fContent = array_unique($fLinks);
                foreach($fContent as $fValue){
                    $finLinks[] = $fValue;
                }
            }
        }
        return $finLinks;
    }

    function getInfo($i=0){
        $this->allContent = @file_get_contents($this->str);
        if($http_response_header != null){
            $curHeaders = $this->headers[] = $this->getHeaders($http_response_header);
        }
        if($curHeaders['Response_code'] == 200){
            $this->getDesc($curHeaders['Charset']);
            $this->links = $this->getLinks();
        }
        else{
            fputs(STDERR, "No connection to $this->str \r\n");
//            echo "No connection to $this->str \r\n";
        }
        if($i < 99 && count($this->desc) < 10){
            $i++;
            $this->str = $this->links[$i];
            $this->getInfo($i);
        }
    }
}
?>