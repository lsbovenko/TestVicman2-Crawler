<?php
header('Content-Type: text/html; charset=utf-8');
require("BaseCr.class.php");
$arrayRes = BaseCr::getInstance()->getInfo();
echo json_encode($arrayRes);
?>