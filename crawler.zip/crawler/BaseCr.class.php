<?php
class BaseCr{
    public $connection;
    private static $_instance;

    private function __construct(){
        $conn = @mysqli_connect('localhost', 'root', '') or die("Не возможно соединиться с базой");
        $sqlBase = "CREATE DATABASE Crawler";
        mysqli_query($conn, $sqlBase);
        mysqli_close($conn);
        $this->connection = @mysqli_connect('localhost', 'root', '', 'Crawler') or die("Не возможно соединиться с базой");
    }

    static function getInstance(){
        if(self::$_instance == null){
            self::$_instance = new BaseCr();
        }
        return self::$_instance;
    }

    function cTable(){
        $sqlTable = "SHOW TABLES LIKE 'Info'";
        if((mysqli_query($this->connection, $sqlTable)->num_rows) == 0){
            $sqlCTable = "CREATE TABLE Info (Id INT(3) AUTO_INCREMENT PRIMARY KEY, Domain VARCHAR(50), Link VARCHAR(100), Content VARCHAR(300))";
            mysqli_query($this->connection, $sqlCTable);
        }
        else{
//            $sqlClTable = "DELETE FROM Info";
//            mysqli_query($this->connection, $sqlClTable);
        }
    }

    function setInfo($domain, $link, $content){
        $sqlSet = "INSERT INTO Info (Domain, Link, Content) VALUES ('$domain', '$link', '$content')";
        mysqli_query($this->connection, $sqlSet);
    }

    function getInfo(){
        $sqlGet = "SELECT * FROM Info";
        $resValues = mysqli_query($this->connection, $sqlGet);
        while($item = mysqli_fetch_assoc($resValues)){
            $values[] = array('Domain'=>$item['Domain'], 'Link'=>$item['Link'], 'Content'=>$item['Content']);
        }
        return $values;
    }
}
?>